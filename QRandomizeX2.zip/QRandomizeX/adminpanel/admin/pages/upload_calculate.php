
<link href="./css/mycss.css" rel="stylesheet">
<div class="app-main__outer">
        <div class="app-main__inner">
            <div>
            <form action="" method="post" class='form-design' enctype="multipart/form-data">
                <h1 class='upload-text'>UPLOAD FILE</h1>
                <p>Upload your hard copy test paper to calculate score</p>
                <!-- actual upload which is hidden -->
                <input type="file" name='file' id="actual-btn" required/>
                <input type="submit" value="Upload to Calculate" class="btn-upload" name='submit'>
            </form>
            </div>
        </div>
        <div class="body-form-upload">

        <?php

        include("../../conn.php");
        require 'vendor/autoload.php';
        use Smalot\PdfParser\Parser;


        if(isset($_POST['submit'])){

            $fileData = $_FILES["file"];
            $pdfFile = $_FILES["file"]["tmp_name"];
            $parser = new Parser();
            $pdf = $parser->parseFile($pdfFile);
            $text = $pdf->getText();
            $convertedText = nl2br($text);
        
            $questionsArray = array_filter(array_map('trim', explode("\n", $convertedText)));
            
            $fullName = 'Fullname';
            $examTitle = 'Subject';
            $questions = '.)';
            $answer = '_____';

            $getTitleOfExam = searchArrayString($questionsArray, $examTitle);
            $getExmneId = searchArrayString($questionsArray, $fullName);

            $textArray = $questionsArray[2];
            $topicTitile =  str_replace("	","",$textArray);
            $topicTitile =  str_replace("<br />","",$topicTitile);
                
            $sql1 = "SELECT
                distinct
                ex_id,
                ex_title,
                ex_questlimit_display as ex_item
            FROM
                exam_tbl
                 WHERE ex_title = '" . $topicTitile ."'";
            

            $selExamAttmpt1 = $conn->query($sql1);

            $result1 = $selExamAttmpt1->fetch(PDO::FETCH_ASSOC);
            $ex_id = $result1['ex_id'];
        
            $arrayExmneId = array_values($getExmneId);

            $fullName = str_replace("Fullname	: ","", $arrayExmneId[0]);
            $cleanFullname = str_replace("	","",$fullName);
            $cleanFullname =  str_replace("<br />","",$cleanFullname);

            $sql2 = "
            SELECT distinct exmne_id 
            FROM examinee_tbl
            WHERE exmne_fullname = '".$cleanFullname."'";

            $selExamAttmpt2 = $conn->query($sql2);
            $result1 = $selExamAttmpt2->fetch(PDO::FETCH_ASSOC);

            $exmne_id = $result1['exmne_id'];


            $questionForm = searchArrayString($questionsArray, $questions);
            $answerItem = searchArrayString($questionsArray,  $answer);
        
            $arrayKeyPerQuestuionVal = array_values($questionForm);
            $arrayKeyPErAnswerVal = array_values($answerItem);

            $question = count($arrayKeyPerQuestuionVal);

            $removeNo = 1;
            $exam_with_q = [];
            $y = 0;

            $exam_ch = '"N/A" as exam_ch1';

            $takeSQL1 = "SELECT * FROM exam_attempt WHERE exmne_id='$exmne_id' AND exam_id='$ex_id'";
            $takeSQL2 = "SELECT * FROM exam_answers WHERE axmne_id='$exmne_id' AND exam_id='$ex_id'";
      

            $selExAttempt = $conn->query($takeSQL1);
            $selAns = $conn->query($takeSQL2);

            if($selExAttempt->rowCount() > 0)
            {
                $res = array("res" => "alreadyTaken");
                
            }else if($selAns->rowCount() > 0)
            {

                $sqlUpdate = "UPDATE exam_answers SET exans_status='old' 
                WHERE axmne_id='$exmne_id' AND exam_id='$ex_id'";
    
                $updLastAns = $conn->query($sqlUpdate);
                for($x = 0; $x < $question; $x++){
                
                    $removeColon = str_replace(".) ","",$arrayKeyPerQuestuionVal[$x]);
                    $items = (string)$removeNo;
                    $removeNumber = str_replace($items . " ","",$removeColon);

                    $removeTab = str_replace("	","",$removeNumber);
                    $removeBreak =  str_replace("<br />","",$removeTab);

                    $get40Characters =  mb_substr($removeBreak, 0, 40);

                    $getAnswerQ = substr($arrayKeyPErAnswerVal[$y], strpos($arrayKeyPErAnswerVal[$y], "_") + 1);

                    $qAnswerClean = str_replace("	","",$getAnswerQ);
                    $qAnswerClean = str_replace("_","",$qAnswerClean);
                    $qAnswerClean = str_replace("<br />","",$qAnswerClean);
                    $qAnswerClean = str_replace(" ","",$qAnswerClean);

                    if($qAnswerClean == 'A'){
                        $exam_ch = 'exam_ch1';
                    }
                    if($qAnswerClean =='B'){
                        $exam_ch = 'exam_ch2';
                    }
                
                    if($qAnswerClean == 'C'){
                        $exam_ch = 'exam_ch3';
                    }
                    if($qAnswerClean == 'D'){
                        $exam_ch = 'exam_ch4';
                    }
               

                    $sql3 = "
                        SELECT
                        distinct
                        eqt_id,
                        exam_id,
                        exam_question,
                        $exam_ch
                        FROM exam_question_tbl
                        WHERE exam_question LIKE '%".$get40Characters."%' and exam_id = '$ex_id';
                        ";
                
                    $selExamAttmpt3 = $conn->query($sql3);
                    $resultQ = $selExamAttmpt3->fetch(PDO::FETCH_ASSOC);

                    $eqt_id = $resultQ['eqt_id'];
                    $exam_id = $resultQ['exam_id'];
                    $exmne_id;
                    $answerid = $resultQ[$exam_ch];

                    $insAns = $conn->query("INSERT INTO exam_answers(axmne_id,exam_id,quest_id,exans_answer) VALUES('$exmne_id','$exam_id','$eqt_id','$answerid')");
     
                    $removeNo += 1;
                    $y += 1;

        
                }
                echo "Successfully Calculated";
                
                
    
            }
            else
            {

                for($x = 0; $x < $question; $x++){
                
                    $removeColon = str_replace(".) ","",$arrayKeyPerQuestuionVal[$x]);
                    $items = (string)$removeNo;
                    $removeNumber = str_replace($items . " ","",$removeColon);

                    $removeTab = str_replace("	","",$removeNumber);
                    $removeBreak =  str_replace("<br />","",$removeTab);

                    $get40Characters =  mb_substr($removeBreak, 0, 40);

                    $getAnswerQ = substr($arrayKeyPErAnswerVal[$y], strpos($arrayKeyPErAnswerVal[$y], "_") + 1);

                    $qAnswerClean = str_replace("	","",$getAnswerQ);
                    $qAnswerClean = str_replace("_","",$qAnswerClean);
                    $qAnswerClean = str_replace("<br />","",$qAnswerClean);
                    $qAnswerClean = str_replace(" ","",$qAnswerClean);

                    if($qAnswerClean == 'A'){
                        $exam_ch = 'exam_ch1';
                    }
                    if($qAnswerClean =='B'){
                        $exam_ch = 'exam_ch2';
                    }
                
                    if($qAnswerClean == 'C'){
                        $exam_ch = 'exam_ch3';
                    }
                    if($qAnswerClean == 'D'){
                        $exam_ch = 'exam_ch4';
                    }
               

                    $sql3 = "
                        SELECT
                        distinct
                        eqt_id,
                        exam_id,
                        exam_question,
                        $exam_ch
                        FROM exam_question_tbl
                        WHERE exam_question LIKE '%".$get40Characters."%' and exam_id = '$ex_id';
                        ";
                
                    $selExamAttmpt3 = $conn->query($sql3);
                    $resultQ = $selExamAttmpt3->fetch(PDO::FETCH_ASSOC);

                    $eqt_id = $resultQ['eqt_id'];
                    $exam_id = $resultQ['exam_id'];
                    $exmne_id;
                    $answerid = $resultQ[$exam_ch];

                    $insAns = $conn->query("INSERT INTO exam_answers(axmne_id,exam_id,quest_id,exans_answer) VALUES('$exmne_id','$exam_id','$eqt_id','$answerid')");
     
                    $removeNo += 1;
                    $y += 1;

        
                }

                $insAttempt = $conn->query("INSERT INTO exam_attempt(exmne_id,exam_id)  VALUES('$exmne_id','$ex_id') ");
                if($insAttempt)
                {
                    echo "Successfully Calculated";
                }

            }

          
        
        }

        function getCenterCharacters($input) {

            $length = strlen($input);
            $centerIndex = floor($length / 2);
        
            if ($length % 2 == 0) {
                // Even length string
                $centerChars = substr($input, $centerIndex - 1, 2);
            } else {
                // Odd length string
                $centerChars = $input[$centerIndex];
            }
        
            return $centerChars;
        }

        function searchArrayString($array, $searchString){
    
            $result = array_filter($array, function($value) use ($searchString) {
                return strpos($value, $searchString) !== false;
            });
        
            return $result;
        }
        
        
        function getCenterSubstring($text, $length) {
            $textLength = strlen($text);
            
            // Ensure the length is not greater than the text length
            if ($length > $textLength) {
                return $text;
            }
            
            // Calculate the starting position
            $start = ($textLength - $length) / 2;
            
            // Extract the substring
            $centerSubstring = substr($text, $start, $length);
            
            return $centerSubstring;
        }

    
    ?>

</div>
<div>
<table class="align-middle mb-0 table table-borderless table-striped table-hover" id="tableList">
                            <thead>
                            <tr>
                                <th>Fullname</th>
                                <th>Exam Name</th>
                                <th>Scores</th>
                                <th>Ratings</th>
    
                            </tr>
                            </thead>
                            <tbody>
                              <?php 
                                $selExmne = $conn->query("SELECT * FROM examinee_tbl et INNER JOIN exam_attempt ea ON et.exmne_id = ea.exmne_id ORDER BY ea.examat_id DESC ");
                                if($selExmne->rowCount() > 0)
                                {
                                    while ($selExmneRow = $selExmne->fetch(PDO::FETCH_ASSOC)) { ?>
                                        <tr>
                                           <td><?php echo $selExmneRow['exmne_fullname']; ?></td>
                                           <td>
                                             <?php 
                                                $eid = $selExmneRow['exmne_id'];
                                                $selExName = $conn->query("SELECT * FROM exam_tbl et INNER JOIN exam_attempt ea ON et.ex_id=ea.exam_id WHERE  ea.exmne_id='$eid' ")->fetch(PDO::FETCH_ASSOC);
                                                $exam_id = $selExName['ex_id'];
                                                echo $selExName['ex_title'];
                                              ?>
                                           </td>
                                           <td>
                                                    <?php 
                                                    $selScore = $conn->query("SELECT * FROM exam_question_tbl eqt INNER JOIN exam_answers ea ON eqt.eqt_id = ea.quest_id AND eqt.exam_answer = ea.exans_answer  WHERE ea.axmne_id='$eid' AND ea.exam_id='$exam_id' AND ea.exans_status='new' ");
                                                      ?>
                                                <span>
                                                    <?php echo $selScore->rowCount(); ?>
                                                    <?php 
                                                        $over  = $selExName['ex_questlimit_display'];
                                                     ?>
                                                </span> / <?php echo $over; ?>
                                           </td>
                                           <td>
                                              <?php 
                                                    $selScore = $conn->query("SELECT * FROM exam_question_tbl eqt INNER JOIN exam_answers ea ON eqt.eqt_id = ea.quest_id AND eqt.exam_answer = ea.exans_answer  WHERE ea.axmne_id='$eid' AND ea.exam_id='$exam_id' AND ea.exans_status='new' ");
                                                ?>
                                                <span>
                                                    <?php 
                                                        $score = $selScore->rowCount();
                                                        $ans = $score / $over * 100;
                                                        echo number_format($ans,2);
                                                        // echo "$ans";
                                                        echo "%";
                                                        
                                                     ?>
                                                </span> 
                                           </td>
                                        </tr>
                                    <?php }
                                }
                                else
                                { ?>
                                    <tr>
                                      <td colspan="2">
                                        <h3 class="p-3">No Course Found</h3>
                                      </td>
                                    </tr>
                                <?php }
                               ?>
                            </tbody>
                        </table>
</div>



