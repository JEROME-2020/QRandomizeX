
<div class="app-main__outer">
        <div class="app-main__inner">
            <div>
            <h2>Upload a File</h2>
            <form action="" method="post" enctype="multipart/form-data">
                <label for="file">Choose file to upload:</label>
                <input type="file" name="file" id="file" required>
                <br><br>
                <input type="submit" value="Upload File" class="btn btn-sm btn-primary" name='submit'>
            </form>
            </div>
        </div>
</div>
<?php

require 'vendor/autoload.php';

use Smalot\PdfParser\Parser;


if(isset($_POST['submit'])){

    $fileData = $_FILES["file"];

    // Path to the PDF file
    $pdfFile = $_FILES["file"]["tmp_name"];

    // Create a new instance of the PDF parser
    $parser = new Parser();

    // Parse the PDF file
    $pdf = $parser->parseFile($pdfFile);

    // Extract text from the PDF
    $text = $pdf->getText();

    // Output the extracted text
    echo nl2br($text);

    
  
}
