
<link href="./css/mycss.css" rel="stylesheet">
<div class="app-main__outer">
        <div class="app-main__inner">
            <div>
            <form action="" method="post" class='form-design' enctype="multipart/form-data">
                <h1 class='upload-text'>UPLOAD FILE</h1>
                <p>Upload your hard copy test paper to calculate score</p>
                <!-- actual upload which is hidden -->
                <input type="file" name='file' id="actual-btn" required/>
                <input type="submit" value="Upload File" class="btn-upload" name='submit'>
            </form>
            </div>
        </div>
        <div class="body-form-upload">

        <?php

        include("../../conn.php");
        require 'vendor/autoload.php';
        use Smalot\PdfParser\Parser;


        if(isset($_POST['submit'])){

            $fileData = $_FILES["file"];
            $pdfFile = $_FILES["file"]["tmp_name"];
            $parser = new Parser();
            $pdf = $parser->parseFile($pdfFile);
            $text = $pdf->getText();
            $convertedText = nl2br($text);

            echo "<span class='result-pdf-text'>" . $convertedText . "</span>";
            echo "<form>";
            echo "<br>"; 
            echo "<input type='submit' class='btn-upload' value='calculate score'>";
            echo "</form>";
        
            $questionsArray = array_filter(array_map('trim', explode("\n", $convertedText)));
            
            $fullName = 'Fullname';
            $examTitle = 'Subject';
            $questions = '.)';
            $answer = '_____';

            $getTitleOfExam = searchArrayString($questionsArray, $examTitle);
            $getExmneId = searchArrayString($questionsArray, $fullName);

            $textArray = $questionsArray[2];
            $topicTitile =  str_replace("	","",$textArray);
            $topicTitile =  str_replace("<br />","",$topicTitile);
                
            $sql1 = "SELECT
                distinct
                ex_id,
                ex_title,
                ex_questlimit_display as ex_item
            FROM
                exam_tbl
                 WHERE ex_title = '" . $topicTitile ."'";
            

            $selExamAttmpt1 = $conn->query($sql1);

            $result1 = $selExamAttmpt1->fetch(PDO::FETCH_ASSOC);
            $ex_id = $result1['ex_id'];
        
            $arrayExmneId = array_values($getExmneId);

            $fullName = str_replace("Fullname	: ","", $arrayExmneId[0]);
            $cleanFullname = str_replace("	","",$fullName);
            $cleanFullname =  str_replace("<br />","",$cleanFullname);

            $sql2 = "
            SELECT distinct exmne_id 
            FROM examinee_tbl
            WHERE exmne_fullname = '".$cleanFullname."'";

            $selExamAttmpt2 = $conn->query($sql2);
            $result1 = $selExamAttmpt2->fetch(PDO::FETCH_ASSOC);

            $exmne_id = $result1['exmne_id'];


            echo $ex_id;
            echo "<br>";
            echo $exmne_id;
            echo "<br>";

            $questionForm = searchArrayString($questionsArray, $questions);
            $answerItem = searchArrayString($questionsArray,  $answer);
        
            $arrayKeyPerQuestuionVal = array_values($questionForm);
            $arrayKeyPErAnswerVal = array_values($answerItem);

            $question = count($arrayKeyPerQuestuionVal);

            $removeNo = 1;

            for($x = 0; $x < $question; $x++){

                
                $removeColon = str_replace(".) ","",$arrayKeyPerQuestuionVal[$x]);
                $items = (string)$removeNo;
                $removeNumber = str_replace($items . " ","",$removeColon);

                $removeTab = str_replace("	","",$removeNumber);
                $removeBreak =  str_replace("<br />","",$removeTab);

                $get40Characters =  mb_substr($removeBreak, 0, 40);

                $sql3 = "
                SELECT
                distinct
                eqt_id,
                exam_id,
                exam_question
                FROM exam_question_tbl
                WHERE exam_question LIKE '%".$get40Characters."%' and exam_id = '$ex_id';
                ";

                $selExamAttmpt3 = $conn->query($sql3);
                $resultQ = $selExamAttmpt3->fetch(PDO::FETCH_ASSOC);


                echo "<br>";
                echo "--------------";
                echo "<br>";
                echo $resultQ['eqt_id'];
                echo "<br>";
                echo $resultQ['exam_id'];
                echo "<br>";
                echo "--------------";
                echo "<br>";
                echo $exmne_id;
                echo "<br>";
                echo "--------------";
                echo "<br>";


                // echo "<br>";

                // echo "<pre>";
                // print_r($resultQ['eqt_id']);
                // echo "</pre>";
                
                $removeNo += 1;

            }


            // $sss = str_replace("	<br />","", $arrayKeyPErAnswerVal[0]);

            
            // echo "<script>";

            // echo "alert('".$sss."')";
            // echo "</script>";



            // SELECT 
            // eqt_id,
            // exam_id
            // FROM qrandomizex.exam_question_tbl
            // WHERE exam_question LIKE '%What diagram is an effective tool to identify prior knowledge and set own targets and means of%'




            

        

            // print_r($arrayKeyPerQuestuionVal);

            // echo "<br>";
            // echo "<br>"; 
            // echo "<pre>";
            // print_r($arrayKeyPErAnswerVal);
            // echo "</pre>";

       
        

        
        }

        function searchArrayString($array, $searchString){
    
            $result = array_filter($array, function($value) use ($searchString) {
                return strpos($value, $searchString) !== false;
            });
        
            return $result;
        }
        
        
        function getCenterSubstring($text, $length) {
            $textLength = strlen($text);
            
            // Ensure the length is not greater than the text length
            if ($length > $textLength) {
                return $text;
            }
            
            // Calculate the starting position
            $start = ($textLength - $length) / 2;
            
            // Extract the substring
            $centerSubstring = substr($text, $start, $length);
            
            return $centerSubstring;
        }

    
    ?>

</div>

